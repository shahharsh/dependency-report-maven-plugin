package com.netflix.mojo.dependencyreport;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.MojoFailureException;
import org.apache.maven.plugins.annotations.LifecyclePhase;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;

import com.netflix.mojo.dependencyreport.artifact.Artifact;
import com.netflix.mojo.dependencyreport.artifact.ArtifactList;

import org.apache.commons.io.FileUtils;

/**
 * This goal generates dependency report by reading a text file
 */
@Mojo(name = "dependency-report", requiresProject = false, threadSafe = true, defaultPhase = LifecyclePhase.INITIALIZE, aggregator = true)
public class DependencyReportMojo extends AbstractMojo {

    /**
     * Location of text file
     */
    @Parameter(property = "graphfile", defaultValue = "${project.basedir}/src/main/resources/graph.txt")
    private File todir;

    public void execute() throws MojoExecutionException, MojoFailureException {
        try {
            ArtifactList artifactList = new ArtifactList();
            List<Artifact> seen = new ArrayList<Artifact>();
            readDependency(artifactList);
            artifactList.walkDependency(artifactList.getArtifact("A"), artifactList, seen, 0);
            for(Artifact artifact : artifactList.getArtifactList()) {
                if(!artifact.isVisited()) {
                    artifactList.walkDependency(artifact, artifactList, seen, 0);
                }
            }
        } catch (Exception e) {
            throw new MojoExecutionException("Unable to generate dependecy report", e);
        }

    }

    private void readDependency(ArtifactList artifactList) {
        List<String> lines;
        try {
            lines = FileUtils.readLines(todir, "UTF-8");
            if(lines.isEmpty()) {
                System.out.println("File is empty");
                return;
            }
            for (String line : lines) {
                Artifact artifact = new Artifact(line.substring(0, 1));
                Artifact child = new Artifact(line.substring(line.length() - 1, line.length()));
                artifactList.addArtifact(artifact);
                artifactList.addArtifact(child);
                artifactList.upDateChildren(artifact, child);
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            System.out.println("Unable to generate dependecy report" + e.getStackTrace().toString());
        }
    }
}
