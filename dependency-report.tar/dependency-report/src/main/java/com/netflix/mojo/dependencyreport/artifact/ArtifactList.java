package com.netflix.mojo.dependencyreport.artifact;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class ArtifactList {
    Set<Artifact> artifactList;

    public ArtifactList() {
        this.artifactList = new HashSet<Artifact>();
    }

    public boolean addArtifact(Artifact node) {
        return this.artifactList.add(node);
    }

    public boolean contains(Artifact artifact) {
        return this.artifactList.contains(artifact);
    }

    public Artifact getArtifact(String artifact) {
        Iterator<Artifact> iterator = artifactList.iterator();
        while (iterator.hasNext()) {
            Artifact tempArtifact = iterator.next();
            if (tempArtifact.artifactName.matches(artifact)) {
                return tempArtifact;
            }
        }
        return null;
    }

    public List<Artifact> getArtifactList() {
        List<Artifact> artifactArrayList = new ArrayList<Artifact>();
        for (Artifact artifact : artifactList) {
            artifactArrayList.add(artifact);

        }
        return artifactArrayList;
    }

    public boolean upDateChildren(Artifact artifact, Artifact child) {
        Iterator<Artifact> iterator = artifactList.iterator();
        while (iterator.hasNext()) {
            Artifact tempArtifact = iterator.next();
            if (tempArtifact.equals(artifact)) {
                return tempArtifact.addChildren(child);
            }
        }
        return false;
    }

    public boolean removeArtifact(Artifact node) {
        return this.artifactList.remove(node);
    }

    public void walkDependency(Artifact artifact, ArtifactList artifactList, List<Artifact> seen, int i) {
        this.printDependency(artifact, i);
        seen.add(artifact);
        artifact.setVisited(true);
        for (Artifact child : artifact.getChildren()) {
            if (seen.indexOf(child) != -1) {
                // this.printDependency(child, i + 2);
                System.out.println("\tcyclic dependency detected returning " + child.getArtifactName());
                return;
            }
            walkDependency(artifactList.getArtifact(child.getArtifactName()), artifactList, seen, i + 2);
        }
        seen.remove(artifact);

    }

    private void printDependency(Artifact artifact, int i) {
        for (int j = 0; j < i - 1; j++) {
            System.out.print(" ");
            if (j == i - 2) {
                System.out.print("|_");
            }
        }

        System.out.print(" " + artifact.getArtifactName());
        System.out.println();
    }

}
