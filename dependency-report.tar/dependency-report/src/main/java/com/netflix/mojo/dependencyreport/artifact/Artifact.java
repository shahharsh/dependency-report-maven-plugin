package com.netflix.mojo.dependencyreport.artifact;

import java.util.HashSet;

public class Artifact {
    String artifactName;
    boolean visited;

    public boolean isVisited() {
        return visited;
    }

    public void setVisited(boolean visited) {
        this.visited = visited;
    }

    HashSet<Artifact> children;

    public HashSet<Artifact> getChildren() {
        return children;
    }

    public void setChildren(HashSet<Artifact> children) {
        this.children = children;
    }

    public Artifact(String name) {
        this.artifactName = name;
        visited = false;
        children = new HashSet<Artifact>();
    }

    public boolean addChildren(Artifact child) {
        return this.children.add(child);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof Artifact)) {
            return false;
        }
        Artifact artifact = (Artifact) obj;
        return artifact.artifactName.contentEquals(artifactName);
    }

    public String getArtifactName() {
        return artifactName;
    }

    public void setArtifactName(String artifactName) {
        this.artifactName = artifactName;
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + artifactName.hashCode();
        return result;
    }

}
