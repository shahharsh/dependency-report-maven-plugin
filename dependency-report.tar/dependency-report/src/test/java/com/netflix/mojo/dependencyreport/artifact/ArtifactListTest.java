package com.netflix.mojo.dependencyreport.artifact;

import org.junit.Assert;
import org.junit.Test;

public class ArtifactListTest {

    @Test
    public void testArtifactListContains() throws Exception {

        ArtifactList artifactList = this.simulateArtifactList();
        artifactList.getArtifactList();

        Assert.assertTrue(artifactList.contains(artifactList.getArtifact("A")));
        Assert.assertFalse(artifactList.contains(artifactList.getArtifact("F")));

    }

    @Test
    public void testArtifactListUpdateChildren() throws Exception {

        ArtifactList artifactList = this.simulateArtifactList();
        Assert.assertTrue(artifactList.upDateChildren(artifactList.getArtifact("A"), artifactList.getArtifact("E")));
        // can add more test here, need more time
    }

    @Test
    public void testArtifactListGetList() throws Exception {

        ArtifactList artifactList = this.simulateArtifactList();

        Assert.assertEquals(artifactList.getArtifactList().size(), 5);
        // can add more test here, need more time
    }

    private ArtifactList simulateArtifactList() {
        // TODO Auto-generated method stub
        ArtifactList artifactList = new ArtifactList();
        Artifact testArtifact = new Artifact("A");
        Artifact testArtifact1 = new Artifact("B");
        testArtifact.addChildren(testArtifact1);
        Artifact testArtifact2 = new Artifact("C");
        testArtifact1.addChildren(testArtifact2);
        Artifact testArtifact3 = new Artifact("D");
        testArtifact1.addChildren(testArtifact3);
        Artifact testArtifact4 = new Artifact("E");
        testArtifact3.addChildren(testArtifact4);
        Assert.assertTrue(artifactList.addArtifact(testArtifact));
        Assert.assertTrue(artifactList.addArtifact(testArtifact1));
        Assert.assertTrue(artifactList.addArtifact(testArtifact2));
        Assert.assertTrue(artifactList.addArtifact(testArtifact3));
        Assert.assertTrue(artifactList.addArtifact(testArtifact4));

        return artifactList;
    }

}