package com.netflix.mojo.dependencyreport;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.util.Scanner;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import io.takari.maven.testing.TestResources;
import io.takari.maven.testing.executor.MavenExecution;
import io.takari.maven.testing.executor.MavenExecutionResult;
import io.takari.maven.testing.executor.MavenRuntime;
import io.takari.maven.testing.executor.MavenRuntime.MavenRuntimeBuilder;
import io.takari.maven.testing.executor.MavenVersions;
import io.takari.maven.testing.executor.junit.MavenJUnitTestRunner;

@RunWith(MavenJUnitTestRunner.class)
@MavenVersions({ "3.3.9" })
public class DependencyReportMojoTest extends DependencyReportMojo {

    @Rule
    public final TestResources resources = new TestResources();

    public final MavenRuntime maven;

    public DependencyReportMojoTest(MavenRuntimeBuilder builder) throws Exception {
        this.maven = builder.build();
    }

    @Test
    public void testHasErrorFreeLog() throws Exception {

        File project = resources.getBasedir("DependencyReportMojoTest");
        MavenExecution mavenExec = maven.forProject(project);
        MavenExecutionResult result = mavenExec.execute("package");
        result.assertErrorFreeLog();
    }
}